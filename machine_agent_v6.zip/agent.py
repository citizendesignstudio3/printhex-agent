# agent.py
# -*- coding: utf-8 -*-
"""
Agent with a Tk config UI and self-installing startup logic.
- On first run (no --background flag), it configures and sets up a registry key for auto-start.
- On subsequent runs (--background flag set by registry), it runs headless.
- Monitors Serial Port and/or Log File in parallel.
- Original spool monitoring is replaced by log file monitoring.
"""
import time
import json
import threading
import logging
import os
import sys
import subprocess
import queue
import requests

# ✅ Socket.IO handling fix for Windows build
try:
    from socketio import Client, exceptions
except ImportError:
    print("Error: 'python-socketio' not found. Run: pip install python-socketio[client]")
    sys.exit(1)

# ✅ Local module imports
try:
    from version import VERSION
    from updater import check_update_loop
    from parsers.loader import load_parser
except ImportError as e:
    print(f"Warning: Local module missing: {e}")
    VERSION = "1.0.0"

# Windows-specific import for registry
try:
    import winreg
except ImportError:
    winreg = None

# UI Imports
try:
    import tkinter as tk
    from tkinter import messagebox, filedialog
except Exception:
    tk = messagebox = filedialog = None

# Serial handling
try:
    import serial
    from serial.serialutil import SerialException
    from serial.tools import list_ports
except Exception:
    serial = SerialException = list_ports = None

# -----------------------
# Centralized default server URL
# -----------------------
DEFAULT_SERVER_URL = os.environ.get("SERVER_URL", "https://python.printhex.in")
REGISTRY_KEY_NAME = "FlexMachineAgent"

# -----------------------
# GUI and validation logic (All logic preserved)
# -----------------------
def create_config_gui(default_server=DEFAULT_SERVER_URL):
    if tk is None:
        sys.exit("Tkinter library not found. Please install 'python3-tk' package.")

    window = tk.Tk()
    window.title("Device Configuration")
    window.geometry("520x420")
    window.resizable(False, False)
    window.attributes('-topmost', True)

    result_queue = queue.Queue()

    def attempt_connection_thread(device_id, jwt_token, server_url):
        temp_sio = Client(reconnection=False, request_timeout=10)
        auth_success = threading.Event()

        @temp_sio.event(namespace='/agent')
        def connect():
            try:
                temp_sio.emit("auth", {"device_id": device_id, "jwt": jwt_token}, namespace='/agent')
            except Exception as e:
                result_queue.put(f"ERROR: Auth emit failed: {e}")
                if temp_sio.connected: temp_sio.disconnect()

        @temp_sio.on('auth_result', namespace='/agent')
        def on_auth_result(data):
            if isinstance(data, dict) and data.get('status') == 'success':
                auth_success.set()
            else:
                error_msg = (data.get('message') if isinstance(data, dict) else 'Unknown authentication error')
                result_queue.put(f"ERROR: {error_msg}")
            if temp_sio.connected: temp_sio.disconnect()

        @temp_sio.event(namespace='/agent')
        def connect_error(err):
            result_queue.put(f"ERROR: Could not connect to the server: {err}")

        @temp_sio.event(namespace='/agent')
        def disconnect():
            if not auth_success.is_set() and result_queue.empty():
                result_queue.put("ERROR: Disconnected before authentication succeeded.")

        try:
            temp_sio.connect(server_url, namespaces=['/agent'])
            if auth_success.wait(timeout=12):
                result_queue.put("SUCCESS")
            else:
                if result_queue.empty():
                    result_queue.put("ERROR: Authentication timed out.")
        except exceptions.ConnectionError as e:
            result_queue.put(f"ERROR: Connection failed: {e}")
        except Exception as e:
            result_queue.put(f"ERROR: Unexpected error: {e}")
        finally:
            if temp_sio.connected: temp_sio.disconnect()

    def check_queue_for_result():
        try:
            message = result_queue.get_nowait()
            if message == "SUCCESS":
                save_to_file(config_data)
            else:
                messagebox.showerror("Validation Failed", message.replace("ERROR: ", ""))
                status_label.config(text="")
                save_button.config(state=tk.NORMAL)
        except queue.Empty:
            window.after(100, check_queue_for_result)

    config_data = {}

    def browse_log_file():
        filepath = filedialog.askopenfilename(
            title="Select Log File",
            filetypes=(("Log files", "*.log"), ("Text files", "*.txt"), ("All files", "*.*"))
        )
        if filepath:
            entry_log_file.delete(0, tk.END)
            entry_log_file.insert(0, filepath)

    def validate_and_save():
        device_id = entry_device_id.get().strip()
        jwt_token = entry_jwt_token.get().strip()
        serial_port = entry_serial_port.get().strip()
        baudrate_text = entry_baudrate.get().strip()
        log_file_path = entry_log_file.get().strip()

        if not device_id or not jwt_token:
            messagebox.showerror("Error", "Both Device ID and Token are required.")
            return

        try:
            baudrate = int(baudrate_text) if baudrate_text else None
        except ValueError:
            messagebox.showerror("Error", "Baudrate must be a number.")
            return

        save_button.config(state=tk.DISABLED)
        status_label.config(text="Connecting to server, please wait...")
        config_data['device_id'] = device_id
        config_data['jwt_token'] = jwt_token
        config_data['server_url'] = entry_server_url.get().strip() or DEFAULT_SERVER_URL
        
        machine_type = entry_machine_type.get().strip()
        if machine_type:
            config_data["machine_type"] = machine_type
        if serial_port:
            config_data["serial_port"] = serial_port
        if baudrate:
            config_data["baudrate"] = baudrate
        if log_file_path:
            config_data["log_file_path"] = log_file_path

        threading.Thread(target=attempt_connection_thread, args=(device_id, jwt_token, config_data['server_url']), daemon=True).start()
        window.after(100, check_queue_for_result)

    def save_to_file(data):
        config_path = get_config_path()
        try:
            with open(config_path, 'w') as f:
                json.dump(data, f, indent=4)
            setup_startup()
            messagebox.showinfo("Setup Complete", "Configuration saved! Please restart the computer.")
            window.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Could not save config: {e}")

    # --- UI elements (All preserved) ---
    tk.Label(window, text="Please enter your device details:", font=("Arial", 12)).pack(pady=(10, 6))
    tk.Label(window, text="Device ID:", font=("Arial", 10)).pack()
    entry_device_id = tk.Entry(window, width=70); entry_device_id.pack()
    
    tk.Label(window, text="Machine Type (flex / uv / eco):", font=("Arial", 9)).pack(pady=(10, 0))
    entry_machine_type = tk.Entry(window, width=30); entry_machine_type.insert(0, "flex"); entry_machine_type.pack()
    
    tk.Label(window, text="Secret / JWT Token:", font=("Arial", 10)).pack(pady=(8, 0))
    entry_jwt_token = tk.Entry(window, width=70); entry_jwt_token.pack()
    
    tk.Label(window, text="Server URL:", font=("Arial", 9)).pack(pady=(8, 0))
    entry_server_url = tk.Entry(window, width=70); entry_server_url.insert(0, default_server); entry_server_url.pack()

    tk.Label(window, text="Serial Port (optional, e.g. COM3):", font=("Arial", 9)).pack(pady=(10, 0))
    entry_serial_port = tk.Entry(window, width=70); entry_serial_port.pack()
    
    tk.Label(window, text="Baudrate (optional, e.g. 9600):", font=("Arial", 9)).pack(pady=(4, 0))
    entry_baudrate = tk.Entry(window, width=20); entry_baudrate.pack()

    tk.Label(window, text="Log File Path (primary monitoring method):", font=("Arial", 9)).pack(pady=(10, 0))
    log_frame = tk.Frame(window)
    entry_log_file = tk.Entry(log_frame, width=55); entry_log_file.pack(side=tk.LEFT, padx=(0, 5))
    tk.Button(log_frame, text="Browse...", command=browse_log_file).pack(side=tk.LEFT)
    log_frame.pack()

    save_button = tk.Button(window, text="Validate and Save Setup", command=validate_and_save, font=("Arial", 11, "bold"))
    save_button.pack(pady=15)
    status_label = tk.Label(window, text="", fg="blue"); status_label.pack()
    window.mainloop()

def get_config_path():
    if getattr(sys, 'frozen', False):
        application_path = os.path.dirname(sys.executable)
    else:
        application_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(application_path, 'config.json')

def setup_startup():
    if not winreg or not getattr(sys, 'frozen', False):
        return
    exe_path = sys.executable
    startup_command = f'"{exe_path}" --background'
    try:
        key_path = r'Software\Microsoft\Windows\CurrentVersion\Run'
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, REGISTRY_KEY_NAME, 0, winreg.REG_SZ, startup_command)
        logging.info("Auto-start setup complete.")
    except Exception as e:
        logging.error(f"Startup setup failed: {e}")

def load_or_create_config(is_background_run):
    config_path = get_config_path()
    if not os.path.exists(config_path) and not is_background_run:
        create_config_gui(DEFAULT_SERVER_URL)
    try:
        with open(config_path, 'r') as f:
            return json.load(f)
    except:
        if is_background_run: sys.exit(1)
        return None

# =========================
# --- मुख्य एजेंट लॉजिक (Full logic preserved) ---
# =========================
IS_BACKGROUND_RUN = '--background' in sys.argv
log_folder = os.path.dirname(get_config_path())
log_path = os.path.join(log_folder, 'agent.log')
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler(log_path, mode='a'), logging.StreamHandler(sys.stdout)])

config = load_or_create_config(IS_BACKGROUND_RUN)
if not config: sys.exit(0)

SERVER_URL = config.get("server_url") or DEFAULT_SERVER_URL
DEVICE_ID = config.get("device_id")
JWT_TOKEN = config.get("jwt_token")
SERIAL_PORT = config.get("serial_port")
BAUDRATE = int(config.get("baudrate")) if config.get("baudrate") else 9600
LOG_FILE_PATH = config.get("log_file_path")
MACHINE_TYPE = config.get("machine_type", "flex")
PARSER = load_parser(MACHINE_TYPE)

sio = Client(reconnection=True, reconnection_attempts=0, reconnection_delay=2)
auth_event = threading.Event()
stop_event = threading.Event()

_last_serial_ts = 0
_last_log_file_ts = 0
_serial_opened = False

# --- Heartbeat, State & Events (All preserved) ---
def heartbeat_loop():
    while not stop_event.is_set():
        if not auth_event.wait(timeout=1): continue
        try:
            if sio.connected:
                sio.emit("heartbeat", {"device_id": DEVICE_ID, "ts": int(time.time() * 1000)}, namespace='/agent')
        except Exception as e:
            logging.error(f"Heartbeat error: {e}")
        stop_event.wait(30)

def send_machine_state(running=True, reason="startup", extra=None):
    try:
        if sio.connected and auth_event.is_set():
            payload = {"device_id": DEVICE_ID, "running": running, "reason": reason, "timestamp": int(time.time() * 1000)}
            if extra: payload.update(extra)
            sio.emit("machine_state", payload, namespace='/agent')
    except Exception as e:
        logging.error(f"State send error: {e}")

def send_device_event(event_type, payload=None):
    try:
        payload = payload or {}
        ev = {"type": event_type, "device_id": DEVICE_ID, "payload": payload, "created_at": int(time.time() * 1000)}
        if sio.connected and auth_event.is_set():
            sio.emit("device_event", ev, namespace='/agent')
    except Exception as e:
        logging.error(f"Event send error: {e}")

# --- Monitor Threads (All logic preserved) ---
def serial_monitor_thread(port, baud):
    global _last_serial_ts, _serial_opened
    if serial is None: return
    try:
        ser = serial.Serial(port, baud, timeout=1)
        _serial_opened = True
        logging.info(f"Serial port {port} opened.")
    except Exception as e:
        logging.error(f"Serial open fail: {e}")
        return
    
    while not stop_event.is_set():
        try:
            raw = ser.readline()
            if raw:
                line = raw.decode('utf-8', errors='replace').strip()
                _last_serial_ts = int(time.time() * 1000)
                send_device_event("serial", {"raw": line})
        except:
            time.sleep(2)
    ser.close()

def log_file_monitor_thread(log_path):
    global _last_log_file_ts
    if not log_path or not os.path.exists(log_path): return
    
    proc = subprocess.Popen(
        ["powershell", "-Command", f'Get-Content "{log_path}" -Wait -Tail 0'],
        stdout=subprocess.PIPE, text=True, creationflags=subprocess.CREATE_NO_WINDOW
    )

    while not stop_event.is_set():
        line = proc.stdout.readline()
        if line:
            _last_log_file_ts = int(time.time() * 1000)
            event = PARSER.parse(line.strip())
            if event: send_device_event(event["event"], event["payload"])
    proc.kill()

def status_report_thread():
    while not stop_event.is_set():
        if auth_event.wait(timeout=1):
            payload = {
                "serial_present": bool(_serial_opened),
                "serial_port": SERIAL_PORT,
                "log_file_present": bool(LOG_FILE_PATH and os.path.exists(LOG_FILE_PATH)),
                "ts": int(time.time() * 1000)
            }
            send_device_event("device_status", payload)
        stop_event.wait(15)

# --- Socket Events (All preserved) ---
@sio.event(namespace='/agent')
def connect():
    sio.emit("auth", {"device_id": DEVICE_ID, "jwt": JWT_TOKEN}, namespace='/agent')

@sio.on('auth_result', namespace='/agent')
def on_auth_result(data):
    if isinstance(data, dict) and data.get('status') == 'success':
        auth_event.set()
        send_machine_state(running=True, reason="auth_success")
    else:
        sio.disconnect()

@sio.on("command", namespace='/agent')
def on_command(data):
    logging.info(f"Command received: {data}")

# ==================================
# --- MAIN EXECUTION ---
# ==================================
if __name__ == "__main__":
    if not all([SERVER_URL, DEVICE_ID, JWT_TOKEN]):
        sys.exit(1)

    if IS_BACKGROUND_RUN:
        threading.Thread(target=check_update_loop, daemon=True).start()
        
        while not stop_event.is_set():
            try:
                sio.connect(SERVER_URL, namespaces=["/agent"])
                break
            except: time.sleep(5)

        threading.Thread(target=heartbeat_loop, daemon=True).start()
        threading.Thread(target=status_report_thread, daemon=True).start()

        if SERIAL_PORT:
            threading.Thread(target=serial_monitor_thread, args=(SERIAL_PORT, BAUDRATE), daemon=True).start()

        if LOG_FILE_PATH and os.path.exists(LOG_FILE_PATH):
            threading.Thread(target=log_file_monitor_thread, args=(LOG_FILE_PATH,), daemon=True).start()
        else:
            # Manual Mode Fallback (All logic as per original code)
            send_device_event("MANUAL_REQUIRED", {"status": "LOG_FILE_MISSING"})
            from manual_mode import manual_status_popup
            def manual_loop():
                while not stop_event.is_set():
                    manual_status_popup(send_device_event)
                    time.sleep(30)
            threading.Thread(target=manual_loop, daemon=True).start()

        sio.wait()