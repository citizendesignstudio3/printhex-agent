class BaseParser:
    def parse(self, line: str):
        return None
