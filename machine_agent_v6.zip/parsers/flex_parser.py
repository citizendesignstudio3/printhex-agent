# parsers/flex_parser.py

import os

class FlexParser:
    """
    Flex Printer Log Parser
    यह parser Flex machine के log keywords को detect करके
    server को proper event भेजेगा।
    """

    def parse(self, line: str):

        # -------------------------
        # POWER STATUS EVENTS
        # -------------------------

        if "Power_On;lParam=1" in line:
            return {
                "event": "POWER_STATUS",
                "payload": {
                    "status": "ON",
                    "raw_log": line
                }
            }

        if "Power_On;lParam=0" in line:
            return {
                "event": "POWER_STATUS",
                "payload": {
                    "status": "OFF",
                    "raw_log": line
                }
            }

        if "==========Status_Change = PowerOff" in line:
            return {
                "event": "POWER_STATUS",
                "payload": {
                    "status": "OFF",
                    "raw_log": line
                }
            }

        # -------------------------
        # MACHINE STATUS EVENTS
        # -------------------------

        if "==========Status_Change = Ready" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Ready",
                    "raw_log": line
                }
            }

        if "==========Status_Change = Busy" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Busy",
                    "raw_log": line
                }
            }

        if "==========Status_Change = Printing" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Printing",
                    "raw_log": line
                }
            }

        if "==========Status_Change = Pause" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Paused",
                    "raw_log": line
                }
            }

        if "==========Status_Change = Initializing" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Initializing",
                    "raw_log": line
                }
            }

        if "==========Status_Change = Moving" in line:
            return {
                "event": "MACHINE_STATUS",
                "payload": {
                    "status": "Moving",
                    "raw_log": line
                }
            }

        # -------------------------
        # JOB EVENTS
        # -------------------------

        if "Job_Begin" in line:
            return {
                "event": "JOB_STATUS",
                "payload": {
                    "status": "Started",
                    "raw_log": line
                }
            }

        if "Job_End" in line:
            return {
                "event": "JOB_STATUS",
                "payload": {
                    "status": "Finished",
                    "raw_log": line
                }
            }

        # -------------------------
        # JOB NAME EXTRACTION
        # -------------------------

        if "start Printing job=" in line:
            try:
                job_path = line.split("start Printing job=")[1].strip()
                return {
                    "event": "JOB_INFO",
                    "payload": {
                        "job_name": os.path.basename(job_path),
                        "status": "Started",
                        "raw_log": line
                    }
                }
            except Exception as e:
                print("Job parse error:", e)
                return None
        return None

        # -------------------------
        # No Match
        # -------------------------
        return None
